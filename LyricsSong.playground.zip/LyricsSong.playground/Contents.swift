//: Playground - noun: a place where people can play

import UIKit


func lyricsSong (totalOfBottles:Int)->String {
    
    var lyrics : String = ""
    for number in (0 ... totalOfBottles).reversed() {
     var newLyrics : String = ""
        
                newLyrics = "\n \(number) Bottles of the beer on the wall, \(number) Bottel of beer.\n Take one down and pass around it , \(number-1) Bottles of beer on the wall\n "
        
            if (number == 1 ){
                newLyrics = "\n one Bottles of the beer on the wall, one Bottel of beer.\n Take one down and pass around it , no Bottles of beer on the wall\n "
               }
            else if (number == 0 ){
                newLyrics = "\n no Bottles of the beer on the wall, no Bottel of beer.\n Take one down and pass around it , no Bottles of beer on the wall\n "
                }
        
        lyrics += newLyrics

    }
    return lyrics
    
}

print (lyricsSong(totalOfBottles:5))



